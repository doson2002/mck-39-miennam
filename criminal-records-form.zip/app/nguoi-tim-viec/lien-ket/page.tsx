import { SocialLinks } from "@/components/jobseeker/social-links"

export default function SocialLinksPage() {
  return <SocialLinks />
}

