import { WorkHistory } from "@/components/jobseeker/work-history"

export default function WorkHistoryPage() {
  return <WorkHistory />
}

