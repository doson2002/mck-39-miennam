import { JobSeekerDashboard } from "@/components/jobseeker/dashboard"

export default function JobSeekerPage() {
  return <JobSeekerDashboard />
}

