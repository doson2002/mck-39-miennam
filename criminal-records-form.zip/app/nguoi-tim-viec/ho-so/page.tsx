import { PersonalProfile } from "@/components/jobseeker/personal-profile"

export default function ProfilePage() {
  return <PersonalProfile />
}

