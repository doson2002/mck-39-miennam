import { BackgroundCheck } from "@/components/employer/background-check"

export default function BackgroundCheckPage() {
  return <BackgroundCheck />
}

