import { CVManagement } from "@/components/employer/cv-management"

export default function CVPage() {
  return <CVManagement />
}

