import { ContractManagement } from "@/components/employer/contract-management"

export default function ContractPage() {
  return <ContractManagement />
}

