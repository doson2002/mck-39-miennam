import { JobPostManagement } from "@/components/employer/job-post-management"

export default function JobPostPage() {
  return <JobPostManagement />
}

