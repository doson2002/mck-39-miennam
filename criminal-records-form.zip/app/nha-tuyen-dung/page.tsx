import { EmployerDashboard } from "@/components/employer/dashboard"

export default function EmployerPage() {
  return <EmployerDashboard />
}

